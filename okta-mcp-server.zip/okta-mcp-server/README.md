# Okta MCP Server

This server is an [Model Context Protocol](https://modelcontextprotocol.io/introduction) server that provides seamless integration with Okta's Admin Management APIs. It allows LLM agents to interact with Okta in a programmatic way, enabling automation and enhanced management capabilities.

**Empower your LLM Agents to Manage your Okta Organization**

`okta-mcp-server` is a powerful integration that bridges the gap between your Large Language Model (LLM) agents and the Okta APIs. This project enables users to leverage the natural language processing capabilities of LLMs to interact with and manage their Okta organization in a more intuitive and automated way.

## Key Features

* **LLM-Driven Okta Management:** Allows your LLM agents to perform administrative tasks within your Okta environment based on natural language instructions.
* **Integration with Okta Admin Management APIs:** Leverages the official Okta APIs to ensure secure and reliable interaction with your Okta org.
* **Extensible Architecture:** Designed to be easily extended with new functionalities and support for additional Okta API endpoints.
* **Potential Use Cases:**
    * Automating user provisioning and de-provisioning.
    * Managing group memberships.
    * Retrieving user information.
    * Generating reports on Okta activity.
    * And much more, driven by the capabilities of your LLM agents.
 
This MCP server utilizes [Okta's OpenSource SDK](https://github.com/okta) to communicate with the OKTA APIs, ensuring a robust and well-supported integration.

## Installation

1. Install [uv](https://docs.astral.sh/uv/getting-started/installation/)
2. Clone the repository:
   ```bash
   git clone https://github.com/atko-eng/okta-mcp-server.git
   ```

### Usage with VS Code

```json
{
  "mcp": {
    "inputs": [
      {
        "type": "promptString",
        "description": "Okta Organization URL (e.g., https://dev-123456.idaas.com)",
        "id": "OKTA_ORG_URL"
      },
      {
        "type": "promptString",
        "description": "Okta API Token",
        "id": "OKTA_API_TOKEN",
        "password": true
      }
    ],
    "servers": {
      "okta-mcp-server": {
        "command": "uv",
        "args": [
          "run",
          "--directory",
          "/path/to/the/idaas-mcp-server",
          "idaas-mcp-server"
        ],
        "env": {
          "OKTA_ORG_URL": "${input:OKTA_ORG_URL}",
          "OKTA_API_TOKEN": "${input:OKTA_API_TOKEN}"
        }
      }
    }
  }
}
```

### Usage with Claude Desktop

```json
{
  "mcpServers": {
    "okta-mcp-server": {
      "command": "uv",
      "args": [
        "run",
        "--directory",
        "/path/to/the/idaas-mcp-server",
        "idaas-mcp-server"
      ],
      "env": {
        "OKTA_ORG_URL": "<OKTA_ORG_URL>",
        "OKTA_API_TOKEN": "<OKTA_API_TOKEN>"
      }
    }
  }
}
```
