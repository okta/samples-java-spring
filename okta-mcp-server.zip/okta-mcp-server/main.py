from src.idaas.server import mcp
import src.idaas.tools.list_users

if __name__ == "__main__":
    # Start the MCP server
    print("Starting Okta MCP Server")
    mcp.run(transport="stdio")
