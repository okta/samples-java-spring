import os
from src.idaas.server import mcp
from okta.client import Client as OktaClient

def get_okta_client() -> OktaClient:
    """Initialize and return an Okta client"""
    config = {
        "orgUrl": os.environ.get("OKTA_ORG_URL"),
        "token": os.environ.get("OKTA_API_TOKEN"),
    }
    return OktaClient(config)

@mcp.tool()
async def list_users() -> list:
    """List all the users in the Okta organization"""
    client = get_okta_client()
    users, _, err = await client.list_users()
    if err:
        return [f"Error: {err}"]
    return [user.profile.login for user in users]
