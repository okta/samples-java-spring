import asyncio

from . import server


def main():
    """Run the server"""
    asyncio.run(server.main())
