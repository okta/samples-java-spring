import os
from mcp.server.fastmcp import FastMCP
from contextlib import asynccontextmanager
from dotenv import load_dotenv
from src.utils.auth.auth_manager import main as okta_auth



load_dotenv()

OKTA_ORG_URL = os.getenv("OKTA_ORG_URL", "https://dev-37673485.okta.com")
OKTA_CLIENT_ID = os.getenv("OKTA_CLIENT_ID", "")
SCOPES = "openid profile email offline_access"
TOKEN_STORE_PATH = os.path.join(os.path.dirname(__file__), ".tokens")

@asynccontextmanager
async def okta_authorisation_flow(server: FastMCP) :

    try:
        print("--- Initiating Session: Performing Authentication ---")
        print("--- Authentication Attempted. Server Starting. ---")
        okta_auth()
        yield
    finally:
        print("Shutting down Okta MCP Server...")

mcp = FastMCP("Okta IDaaS MCP Server",
              lifespan=okta_authorisation_flow)

