# auth.py
import os
import sys
import time
import requests
import webbrowser
import asyncio
from dataclasses import dataclass, field

@dataclass
class OktaAuthManager:
    """Manages Okta configuration, authentication, and token state."""
    org_url: str = field(init=False)
    client_id: str = field(init=False)
    api_token: str | None = None
    token_timestamp: int = 0
    scopes: str = "openid profile email offline_access okta.users.read"

    def __post_init__(self):
        """Initialize and validate Okta configuration from environment variables."""
        org_url = os.environ.get("OKTA_ORG_URL")
        client_id = os.environ.get("OKTA_CLIENT_ID")

        if not org_url or not client_id:
            print("ERROR: OKTA_ORG_URL and OKTA_CLIENT_ID must be set.", file=sys.stderr)
            sys.exit(1)

        self.org_url = org_url if org_url.startswith("https://") else f"https://{org_url}"
        self.client_id = client_id

    async def _initiate_device_authorization(self) -> dict:
        """Initiates the OAuth 2.0 Device Authorization Flow."""
        auth_url = f"{self.org_url}/oauth2/v1/device/authorize"
        headers = {'Accept': 'application/json', 'Content-Type': 'application/x-www-form-urlencoded'}
        data = {'client_id': self.client_id, 'scope': self.scopes}

        try:
            response = await asyncio.to_thread(requests.post, auth_url, headers=headers, data=data)
            response.raise_for_status()
            result = response.json()
            result.update({"start_time": time.time()})
            return result
        except requests.RequestException as e:
            print(f"ERROR: Failed to initiate device authorization: {e}", file=sys.stderr)
            sys.exit(1)

    async def _poll_for_token(self, device_data: dict) -> str | None:
        """Polls the token endpoint until the user authenticates or it times out."""
        token_url = f"{self.org_url}/oauth2/v1/token"
        headers = {'Accept': 'application/json', 'Content-Type': 'application/x-www-form-urlencoded'}
        data = {
            'client_id': self.client_id,
            'device_code': device_data["device_code"],
            'grant_type': 'urn:ietf:params:oauth:grant-type:device_code'
        }

        while time.time() - device_data["start_time"] < device_data["expires_in"]:
            try:
                response = await asyncio.to_thread(requests.post, token_url, headers=headers, data=data)
                resp_json = response.json()

                if response.status_code == 200 and "access_token" in resp_json:
                    return resp_json["access_token"]

                error = resp_json.get("error")
                if error == "authorization_pending":
                    await asyncio.sleep(device_data.get("interval", 5))
                else:
                    print(f"\nERROR: {resp_json.get('error_description', 'Unknown error')}", file=sys.stderr)
                    return None
            except requests.RequestException as e:
                print(f"\nERROR during token polling: {e}", file=sys.stderr)
                await asyncio.sleep(device_data.get("interval", 5))

        print("ERROR: Device authorization timed out.", file=sys.stderr)
        return None

    async def authenticate(self):
        """Orchestrates the full device authentication flow."""
        device_data = await self._initiate_device_authorization()

        print(f"\nPlease complete authentication:\n{device_data['verification_uri_complete']}")
        if device_data.get("user_code"):
            print(f"User code: {device_data['user_code']}")

        try:
            webbrowser.open(device_data["verification_uri_complete"])
            print("Awaiting authentication in your web browser...")
        except Exception:
            print("Please open the URL manually in your browser.")

        token = await self._poll_for_token(device_data)
        if token:
            self.api_token = token
            self.token_timestamp = int(time.time())
            print("Authentication successful. Token securely stored.")
        else:
            print("Authentication failed.")
            sys.exit(1)

    def is_token_valid(self, expiry_duration: int = 3600) -> bool:
        """Checks if the stored API token is present and not expired."""
        is_valid = self.api_token and (time.time() - self.token_timestamp) < expiry_duration
        if not is_valid:
            print("Token has expired or is missing.")
        return is_valid