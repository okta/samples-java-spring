# server.py
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass
from mcp.server.fastmcp import FastMCP
from okta.client import Client as OktaClient
from auth import OktaAuthManager

@dataclass
class AppContext:
    okta_auth_manager: OktaAuthManager

@asynccontextmanager
async def auth_lifespan(server: FastMCP) -> AsyncIterator[AppContext]:
    """
    Manages the application lifecycle. It initializes the OktaAuthManager on startup,
    performs authentication, and yields the context for use in tools.
    """
    print("--- Server Starting: Initializing Okta Auth Manager ---")
    manager = OktaAuthManager()

    print("--- Initiating Session: Performing Authentication ---")
    await manager.authenticate()

    try:
        # Yield the context containing the initialized manager
        yield AppContext(okta_auth_manager=manager)
    finally:
        # Cleanup logic on shutdown
        print("--- Server Shutdown ---")


# Initialize the MCP server with the auth_lifespan manager
mcp = FastMCP("Okta MCP Server", lifespan=auth_lifespan)

def get_okta_client(manager: OktaAuthManager) -> OktaClient:
    """
    Initialize and return an Okta client using the token from the OktaAuthManager.
    """
    if not manager.is_token_valid():
        print("Okta token is invalid or expired.")
        manager.authenticate()

    config = {
        "orgUrl": manager.org_url,
        "token": manager.api_token,
        "clientId": manager.client_id,
        "scopes": manager.scopes
    }
    return OktaClient(config)

@mcp.tool()
async def list_users() -> list:
    """List all the users in the Okta organization"""
    client = get_okta_client()
    users, _, err = await client.list_users()
    if err:
        return [f"Error: {err}"]
    return [user.profile.login for user in users]

@mcp.tool()
def add(a: int, b: int) -> int:
    """Add two numbers."""
    return a + b

if __name__ == "__main__":
    mcp.run()