#auth.py
import functools
import os
import sys
import time
import requests
import webbrowser

SCOPES = "openid profile email offline_access"
OKTA_API_TOKEN = None
OKTA_TOKEN_TIMESTAMP = 0

def get_okta_config():
    # Fetch Okta Org URL and Client ID from environment variables.
    org_url = os.environ.get("OKTA_ORG_URL","https://dev-37673485.okta.com/" )
    client_id = os.environ.get("OKTA_CLIENT_ID", "")

    if not org_url or not client_id:
        print("ERROR: OKTA_ORG_URL and OKTA_CLIENT_ID must be set in environment variables.")
        sys.exit(1)

    if not org_url.startswith("https://"):
        org_url = "https://" + org_url

    return org_url, client_id

def initiate_device_authorization(org_url, client_id):
    # Initiate device authorization.
    auth_url = f"{org_url}/oauth2/v1/device/authorize"
    headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    data = {
        'client_id': client_id,
        'scope': SCOPES
    }

    try:
        response = requests.post(auth_url, headers=headers, data=data)
        response.raise_for_status()
        result = response.json()

        return {
            "device_code": result["device_code"],
            "verification_uri_complete": result["verification_uri_complete"],
            "user_code": result.get("user_code"),
            "interval": result.get("interval", 5),
            "expires_in": result.get("expires_in", 300),
            "start_time": time.time()
        }

    except Exception as e:
        print(f"ERROR: {e}")
        sys.exit(1)

def poll_for_token(org_url, client_id, device_data):
    # Poll token endpoint until success or timeout.
    token_url = f"{org_url}/oauth2/v1/token"
    headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    data = {
        'client_id': client_id,
        'device_code': device_data["device_code"],
        'grant_type': 'urn:ietf:params:oauth:grant-type:device_code'
    }

    while True:
        if time.time() - device_data["start_time"] > device_data["expires_in"]:
            print("ERROR: Device authorization timed out.")
            return None

        try:
            response = requests.post(token_url, headers=headers, data=data)
            resp_json = response.json()

            if response.status_code == 200:
                access_token = resp_json.get("access_token")

                if access_token:
                    # Store token and timestamp
                    global OKTA_API_TOKEN, OKTA_TOKEN_TIMESTAMP
                    OKTA_API_TOKEN = access_token
                    OKTA_TOKEN_TIMESTAMP = int(time.time())
                    os.environ["OKTA_API_TOKEN"] = access_token
                    return access_token

            elif resp_json.get("error") == "authorization_pending":
                sys.stdout.flush()
                time.sleep(device_data["interval"])
            elif resp_json.get("error") == "access_denied":
                print("\nERROR: Access denied.")
                return None
            else:
                print(f"\nERROR: {resp_json.get('error_description', 'Unknown error')}")
                return None

        except Exception as e:
            print(f"\nERROR: {e}")
            time.sleep(device_data["interval"])

def get_token(function):
    @functools.wraps(function)
    def wrapper(*args, **kwargs):
        # Check if the stored token is valid (not older than 1 hour).
        token, timestamp = OKTA_API_TOKEN, OKTA_TOKEN_TIMESTAMP
        if not token or not timestamp:
            print("Starting authentication...")
            main()
        else:
            try:
                token_timestamp = int(timestamp)
                current_time = int(time.time())
                if current_time - token_timestamp < 3600:
                    print("Token is valid.")
                else:
                    print("Your token has expired or is missing. Starting authentication...")
                    main()
            except (ValueError, TypeError):
                # Handles cases where timestamp is not a valid integer
                print("Your token invalid. Starting authentication...")
                main()
        return function(*args, **kwargs)
    return wrapper

def main():
    org_url, client_id = get_okta_config()

    device_data = initiate_device_authorization(org_url, client_id)

    print(f"Please complete authentication:\n{device_data['verification_uri_complete']}")
    if device_data.get("user_code"):
        print(f"User code: {device_data['user_code']}")

    try:
        webbrowser.open(device_data["verification_uri_complete"])
        print("Opening in web browser...")
    except:
        print("Please open the URL manually.")

    token = poll_for_token(org_url, client_id, device_data)

    if token:
        print("Authentication successful. Token securely stored.")
    else:
        print("Authentication failed.")

