#!/bin/bash

# run a build
echo "running a build"
