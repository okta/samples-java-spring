#!/bin/bash

# run a test
echo "running a test"
